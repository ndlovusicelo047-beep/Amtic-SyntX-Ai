# Amtic SyntX AI — Stage 1 Signal Lab
**Signal-only; not live-connected to Weltrade; no trading.**

## App functions
Import one or multiple CSVs with OHLC candles. The app calculates EMA 20/50/200, RSI14, ATR14, recent swing structure and nearest swing support/resistance, then checks candle confirmation. It reports BUY/SELL/WAIT, entry zone, invalidation, ATR/structure stop, TP1/TP2/TP3 (1R/1.5R/2R), setup label (scalp/intraday/swing), and a cash risk-budget estimate. The risk setting is restricted to 0.1–1.0%. Stale, future, or missing timestamps force WAIT (freshness cannot be verified without a timestamp). Use timezone-aware ISO timestamps when possible; broker/server timestamps may not be Harare time, so convert/confirm the timezone before import. WAIT is normal.

## CSV format
Required header: `time,open,high,low,close`. Optional `symbol,timeframe` columns. One row per closed candle, oldest first; minimum 210 candles, 300+ preferred. Filename convention: `Volatility75_M15.csv`. Multiple files can be selected together.

## Install/host from Android (free static host)
GitHub Pages is the first choice—no VPS needed for this static prototype.
1. In Chrome Android, sign in/create GitHub.
2. Create a **public** repo named `amtic-syntx-ai`.
3. Upload `index.html`, `manifest.json`, `sw.js` and this README at repo root.
4. Repo Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
5. Open the URL displayed in Pages settings. Chrome menu → Add to Home screen/Install app.
6. Do not upload secrets, broker logins, tokens, or personal account data to a public repo.

## Test
Tap Load demo data. The demo generator is random and explicitly not broker data. Then try CSV import. Test with a data timestamp within 3 bars of current time; otherwise app intentionally returns WAIT.

## Live-data limitation
Weltrade SyntX is broker-generated, not an exchange dataset. This project does not guess an API endpoint or scrape charts. A broker-authorized read-only feed or an MT5 terminal bridge is needed for live candles. MT5 Android alone cannot stream OHLC into this webpage. An MT5 EA exporting data would normally require desktop MT5 or a VPS; avoid sending account passwords/API tokens to this app.

## Rules and caveats
BUY requires EMA20>EMA50>EMA200 and price above EMA20, higher highs/higher lows, RSI 48–70 and bullish confirmation. SELL is the inverse with RSI 30–52. Otherwise WAIT. Entry is a narrow ATR zone around last close. SL uses 1.5 ATR with a swing-level buffer; targets are 1R, 1.5R, 2R. These are provisional, unbacktested rules. Cash-risk budget is not lot sizing: contract size, tick value, tick size and spread must be verified from the broker before sizing. This is educational only; no profitability claim.

## Demo validation checklist
- Check calculations against an independent chart/indicator on a handful of candles.
- Backtest at least 30 days per instrument/timeframe including spread/slippage, if data is available.
- Forward-test 100+ signals in demo; record WAITs and all losses as well as wins.
- Verify instrument naming, candle close times and contract/tick specifications.
- Do not live trade from this prototype.
